# QHacks_2023 - Garbage Kingston


## Contributors:
---

Author: Ethney Stewart  <br>
Email: 'ethney@cyberstewart.com'<br>

Author: Emily Jiang <br>
Email: 'emilyemilyjiang@outlook.com'<br>

Author: Liyi Ma <br>
Email: '19lm34@queensu.ca'<br>

---

## Descriptions:
This is a IOS/Android app built using Python-Kivy. 

# Setup Details:
Requires kivy package
